﻿namespace AdministrationAPI.Models
{
    public class VoucherStatus
    {
        public string Id { get; set; }
        public string Status { get; set; }  

    }
}
