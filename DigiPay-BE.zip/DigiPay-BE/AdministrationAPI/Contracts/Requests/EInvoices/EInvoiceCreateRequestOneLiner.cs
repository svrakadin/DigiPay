﻿namespace AdministrationAPI.Contracts.Requests.EInvoices
{
    public class EInvoiceCreateRequestOneLiner
    {
        public string Invoice { get; set; }
    }
}
