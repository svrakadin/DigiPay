﻿namespace AdministrationAPI.Contracts.Requests.ExchangeRates
{
    public class CurrencyRequest
    {
        public string Country { get; set; }
        public string Name { get; set; }
    }
}
