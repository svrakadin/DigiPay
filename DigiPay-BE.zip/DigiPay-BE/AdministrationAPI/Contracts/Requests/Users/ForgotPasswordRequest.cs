﻿namespace AdministrationAPI.Contracts.Requests.Users
{
    public class ForgotPasswordRequest
    {
        public string Id { get; set; }
    }
}
