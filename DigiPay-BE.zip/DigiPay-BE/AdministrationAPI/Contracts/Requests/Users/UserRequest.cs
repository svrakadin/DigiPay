namespace AdministrationAPI.Contracts.Requests
{
    public class UserRequest
    {
        public string UserName { get; set; }
    }
}