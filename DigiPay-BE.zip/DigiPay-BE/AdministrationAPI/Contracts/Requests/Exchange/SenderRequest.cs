﻿namespace AdministrationAPI.Contracts.Requests.Exchange
{

    public class SenderRequest
    {
        public string AccountNumber { get; set; }
    }
}
