namespace AdministrationAPI.Contracts.Requests.Transactions


{
    public class ClaimAcceptRequest
    {
        public int TransactionClaimId { get; set; }

    }
}
