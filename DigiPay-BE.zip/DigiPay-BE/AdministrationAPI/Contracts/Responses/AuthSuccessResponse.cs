﻿namespace AdministrationAPI.Contracts.Responses
{
    public class AuthSuccessResponse
    {
        public string Token { get; set; }
        public string UserId { get; set; }
    }
}
