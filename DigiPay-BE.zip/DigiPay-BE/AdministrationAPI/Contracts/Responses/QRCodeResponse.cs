namespace AdministrationAPI.Contracts.Responses
{
    public class QRCodeResponse
    {
        public string? Url { get; set; }
        public string? ManualString { get; set; }
    }
}
