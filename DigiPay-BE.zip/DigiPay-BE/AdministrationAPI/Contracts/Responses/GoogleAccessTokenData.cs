namespace AdministrationAPI.Contracts.Responses
{
    public class GoogleAccessTokenData
    {
        public string Email { get; set; }
        public string Given_name { get; set; }
        public string Familiy_name { get; set; }
    }
}