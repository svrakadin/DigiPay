﻿namespace AdministrationAPI.Contracts.Responses
{
    public class StatusMessageResponse
    {
        public string? Status { get; set; }
        public string? Message { get; set; }
    }
}
