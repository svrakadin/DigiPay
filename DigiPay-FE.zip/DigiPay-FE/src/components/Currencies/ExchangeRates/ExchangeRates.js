export default function ExchangeRates(){
    return (
        <h1>Exchange Rates works!</h1>
    )
}