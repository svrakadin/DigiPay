export const env = {
	ANDROID_API_ENV: {
		url: 'https://processingserver.herokuapp.com',
	},
	API_ENV: {
		url: 'http://siprojekat.duckdns.org:5051',
		testUrl: 'http://localhost:5051',
	},
	NOTIFICATION_API: {
		key: 'Tm1RME5USm1aR1F0T0dRd05TMDBZV1ppTFdFMllXVXRaVFl6WVRka05UZGhaREU0',
		app: 'f5a0e436-9c1a-4f3f-81bd-2ce6a01ab8b7',
	},
};
